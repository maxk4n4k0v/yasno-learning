const {test}=require('node:test'),assert=require('node:assert/strict'),handler=require('../api/tutor.js');
function response(){return {code:0,body:null,setHeader(){},status(n){this.code=n;return this},json(x){this.body=x;return this}}}
test('AI API rejects missing configuration and invalid sessions, validates generated quizzes',async()=>{
 const old={...process.env},originalFetch=global.fetch;
 try{
  delete process.env.OPENROUTER_API_KEY;
  let res=response();await handler({method:'POST',headers:{},body:{}},res);assert.equal(res.code,503);
  process.env.SUPABASE_URL='https://test.invalid';process.env.SUPABASE_ANON_KEY='test';process.env.OPENROUTER_API_KEY='test';
  res=response();await handler({method:'POST',headers:{},body:{}},res);assert.equal(res.code,401);
  const req={method:'POST',headers:{authorization:'Bearer test'},body:{mode:'practice',lessonId:'math-parts',level:1}};
  global.fetch=async()=>({ok:false});res=response();await handler(req,res);assert.equal(res.code,401);
  const quiz={prompt:'Сколько половин в целом?',options:['2','3'],answer:0,explanation:'Две половины — целое.',hint:'Сложи две равные части.'};
  let generated=quiz;
  global.fetch=async url=>({ok:true,json:async()=>url.includes('/rpc/')?true:url.includes('openrouter')?{choices:[{message:{content:JSON.stringify(generated)}}]}:{id:'user'}});
  res=response();await handler(req,res);assert.equal(res.code,200);assert.deepEqual(res.body.question,quiz);
  generated={...quiz,answer:4};res=response();await handler(req,res);assert.equal(res.code,502);
 }finally{global.fetch=originalFetch;for(const k of ['SUPABASE_URL','SUPABASE_ANON_KEY','OPENROUTER_API_KEY']){if(old[k]===undefined)delete process.env[k];else process.env[k]=old[k]}}
});
