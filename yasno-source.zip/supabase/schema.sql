create table if not exists public.learning_profiles (
 user_id uuid primary key references auth.users(id) on delete cascade,
 state jsonb not null default '{}' check (octet_length(state::text)<500000),
 updated_at timestamptz not null default now()
);
alter table public.learning_profiles enable row level security;
create policy "Read own progress" on public.learning_profiles for select to authenticated using ((select auth.uid())=user_id);
create policy "Insert own progress" on public.learning_profiles for insert to authenticated with check ((select auth.uid())=user_id);
create policy "Update own progress" on public.learning_profiles for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
revoke all on public.learning_profiles from anon;
grant select,insert,update on public.learning_profiles to authenticated;
create table public.ai_usage(user_id uuid references auth.users(id) on delete cascade,day date not null,count integer not null default 0,primary key(user_id,day));
alter table public.ai_usage enable row level security;
revoke all on public.ai_usage from anon,authenticated;
create or replace function public.consume_ai_quota() returns boolean language plpgsql security definer set search_path='' as $$
declare updated_count integer;
begin
 if auth.uid() is null then return false; end if;
 insert into public.ai_usage(user_id,day,count) values(auth.uid(),(now() at time zone 'UTC')::date,1)
 on conflict(user_id,day) do update set count=public.ai_usage.count+1 where public.ai_usage.count<30
 returning count into updated_count;
 return updated_count is not null;
end;$$;
revoke all on function public.consume_ai_quota() from public,anon;
grant execute on function public.consume_ai_quota() to authenticated;
