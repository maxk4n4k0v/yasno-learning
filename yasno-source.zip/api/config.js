module.exports = function(req,res){
 const {SUPABASE_URL:url,SUPABASE_ANON_KEY:key,OPENROUTER_API_KEY:ai}=process.env;
 res.setHeader('Cache-Control','no-store');
 res.status(200).json({authReady:!!(url&&key),aiReady:!!(url&&key&&ai),supabaseUrl:url||'',supabaseAnonKey:key||''});
};
