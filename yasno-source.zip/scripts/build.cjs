const esbuild=require('esbuild');
process.chdir(require('path').join(__dirname,'..'));
esbuild.buildSync({stdin:{contents:"export { lessons } from './dist/content.js'; export { validateQuiz } from './dist/learning-core.js';",resolveDir:process.cwd()},bundle:true,format:'cjs',platform:'node',outfile:'lib/learning.cjs'});
esbuild.buildSync({stdin:{contents:"export { createClient } from '@supabase/supabase-js';",resolveDir:process.cwd()},bundle:true,format:'esm',platform:'browser',outfile:'dist/vendor/supabase.js',minify:true});
